program ITProject_P;

uses
  Forms,
  ITProject_U in 'ITProject_U.pas' {fGermistonSPCAForm},
  HelpForm_U in 'HelpForm1\HelpForm_U.pas' {HelpFormMain},
  HelpOwners_U in 'HelpForm1\HelpOwners\HelpOwners_U.pas' {HelpOwners},
  HelpAdoption_U in 'HelpForm1\HelpAdoption\HelpAdoption_U.pas' {HelpAdoption},
  HelpSurrender_U in 'HelpForm1\HelpSurrender\HelpSurrender_U.pas' {HelpSurrender};

{$R *.res}

begin
  Application.Initialize;
  Application.MainFormOnTaskbar := True;
  Application.CreateForm(TfGermistonSPCAForm, fGermistonSPCAForm);
  Application.CreateForm(THelpFormMain, HelpFormMain);
  Application.CreateForm(THelpOwners, HelpOwners);
  Application.CreateForm(THelpAdoption, HelpAdoption);
  Application.CreateForm(THelpSurrender, HelpSurrender);
  Application.Run;
end.
