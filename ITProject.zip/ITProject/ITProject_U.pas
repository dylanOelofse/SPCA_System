unit ITProject_U;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls, pngimage, math, HelpForm_u;

type
  TfGermistonSPCAForm = class(TForm)
    PnlLogo: TPanel;
    PnlPageControl: TPanel;
    pclSpcaTabs: TPageControl;
    tshOwnersDetails: TTabSheet;
    tshAdoptionDetails: TTabSheet;
    tshSurrenderDetails: TTabSheet;
    btnPrevPage2: TButton;
    btnPrevPage: TButton;
    btnSaveClose: TButton;
    btnSurrender: TButton;
    btnAdoption: TButton;
    btnSaveClose2: TButton;
    imgLogo: TImage;
    lblAddress: TLabel;
    lblCell: TLabel;
    btnDisplayOutputOwn: TButton;
    ledName: TLabeledEdit;
    ledSurname: TLabeledEdit;
    ledCell: TLabeledEdit;
    ledDonations: TLabeledEdit;
    ledAge2: TLabeledEdit;
    ledAdoptionFee: TLabeledEdit;
    ledSize2: TLabeledEdit;
    ledAge: TLabeledEdit;
    ledSize: TLabeledEdit;
    ledLocation: TLabeledEdit;
    BtnDisplayOutputSurr: TButton;
    BtnDisplayOutputAdopt: TButton;
    lblAdress1: TLabel;
    lblAdress2: TLabel;
    lblAdress3: TLabel;
    lblSlogan: TLabel;
    lblSlogan1: TLabel;
    lblSlogan2: TLabel;
    lblSlogan3: TLabel;
    redOutGender1: TRichEdit;
    btnGender1: TButton;
    cmbAnimalType: TComboBox;
    cmbPayment: TComboBox;
    cmbDonations: TComboBox;
    redOutList: TRichEdit;
    ledEmailAddress: TLabeledEdit;
    lblPayment: TLabel;
    btnClear: TButton;
    redOutCharacteristics: TRichEdit;
    lblCharacteristics: TLabel;
    redOutCondition: TRichEdit;
    lblCondition: TLabel;
    cmbAnimalType2: TComboBox;
    redOutGender2: TRichEdit;
    tshSave: TTabSheet;
    lstSave: TListBox;
    redOutOwnDet: TRichEdit;
    redOutAdoptDet: TRichEdit;
    redOutSurrDet: TRichEdit;
    btnReset1: TButton;
    btnReset2: TButton;
    btnReset3: TButton;
    btnHelp: TButton;
    btnGender2: TButton;
    procedure FormCreate(Sender: TObject);
    procedure btnAdoptionClick(Sender: TObject);
    procedure btnSurrenderClick(Sender: TObject);
    procedure btnPrevPageClick(Sender: TObject);
    procedure btnSaveCloseClick(Sender: TObject);
    procedure btnPrevPage2Click(Sender: TObject);
    procedure btnSaveClose2Click(Sender: TObject);
    procedure btnDisplayOutputOwnClick(Sender: TObject);
    procedure BtnDisplayOutputAdoptClick(Sender: TObject);
    procedure btnGender1Click(Sender: TObject);
    procedure btnClearClick(Sender: TObject);
    procedure BtnDisplayOutputSurrClick(Sender: TObject);
    procedure cmbDonationsChange(Sender: TObject);
    procedure btnReset1Click(Sender: TObject);
    procedure btnReset2Click(Sender: TObject);
    procedure btnReset3Click(Sender: TObject);
    procedure btnHelpClick(Sender: TObject);
    procedure btnGender2Click(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  fGermistonSPCAForm: TfGermistonSPCAForm;
  tDate, tTime : tDateTime;

implementation

{$R *.dfm}

procedure TfGermistonSPCAForm.btnAdoptionClick(Sender: TObject);
var
    bOwnDetTab : Boolean;
    bAdoptTab : Boolean;
    bAdoptTab2 : Boolean;

begin
    bOwnDetTab := False;
    bAdoptTab := True;
    bAdoptTab2 := True;

    tshAdoptionDetails.Visible := bAdoptTab2;     // Only shows tab 2's heading at run time
    tshAdoptionDetails.TabVisible := bAdoptTab;   // Only tab 2's sheet shows at run time
    tshOwnersDetails.TabVisible := bOwnDetTab;

end;

procedure TfGermistonSPCAForm.btnClearClick(Sender: TObject);
begin
if (MessageDlg('Are you sure you want to clear this information?',
                              mtWarning, [TMsgDlgBtn.mbYes,mbNo],0) = mrYes)    // Displays warning message to clear info in redOutList,
      then                                                                           //click yes to clear and no to cancel.
        redOutList.Clear;
end;

procedure TfGermistonSPCAForm.btnDisplayOutputOwnClick(Sender: TObject);
var
    sName, sSurname, sCell, sEmail, sPayment, sDonations, sDonationOut : String;
    iLength : Integer;
    iLoopDO: Integer;

begin
    sName := ledName.Text;
    sSurname := ledSurname.Text;
    sCell := ledCell.Text;
    sEmail := ledEmailAddress.Text;
    sPayment := cmbPayment.Text;
    sDonations := ledDonations.Text;
    iLength := LENGTH(sCell);

    redOutOwnDet.Lines.Add('Owners Details');
    redOutOwnDet.Lines.Add('Owner: ' + #9 + #9 + #9 + sName + ' ' + sSurname);

    if iLength = 10                                                              // Input vallidation of cellphone number
      then
        begin
          redOutOwnDet.Lines.Add('Cellphone Number: ' + #9 + #9 + sCell);
        end
        else
          begin
            redOutOwnDet.Clear;
            ShowMessage('Invalid Cellphone Number');
            Abort;
          end;

    redOutOwnDet.Lines.Add('Email Address: ' + #9 + #9 + sEmail);
    redOutOwnDet.Lines.Add('Form of Payment: ' + #9 + #9 + SPayment);
    redOutOwnDet.Lines.Add('Donation (R): ' + #9 + #9 + sDonations + '.00');

    for iLoopDO := 1 to redOutList.lines.count do
    begin
      sDonationOut := #9 + #9 + redOutList.Lines[iLoopDo-1];     // When displaying details in main Rich edit in Owners Details tab
                                                                 // (redOutOwnDet) it creates a tab line down the page for the
      if iLoopDO = 1                                             // input in the redOutList when it is displayed.
        then
          begin
            redOutOwnDet.Lines.Add('Donation/s: ' + sDonationOut);
          end
          else
            begin
              redOutOwnDet.Lines.Add(#9 + sDonationOut);
            end;

      end;

    redOutOwnDet.Lines.Add(' ');

    lstSave.Items.Add('Owners Details');
    lstSave.Items.Add('Owner: ' + sName + ' ' + sSurname);
    lstSave.Items.Add('Cellphone Number: ' + sCell);
    lstSave.Items.Add('Email Address: ' + sEmail);
    lstSave.Items.Add('Form of Payment: ' + SPayment);
    lstSave.Items.Add('Donation (R): ' + sDonations + '.00');
    lstSave.Items.Add('Donation/s: ' + redOutList.Text);
    lstSave.Items.Add(' ');

end;

procedure TfGermistonSPCAForm.BtnDisplayOutputAdoptClick(Sender: TObject);
var
    sAge, sAdoptFee, sSize, sAnimalType, sCharacterOut : String;
    iLoopDo : Integer;

begin
    sAge := ledAge.Text;
    sAdoptFee := ledAdoptionFee.Text;
    sSize := ledSize.Text;
    sAnimalType := cmbAnimalType.Text;

    tTime := Now;
    tDate := Now;


    redOutAdoptDet.Lines.Add('Adoption Details ');
    redOutAdoptDet.Lines.Add('Age of animal: ' + #9 + #9 +  sAge);
    redOutAdoptDet.Lines.Add('Adoption Fee: ' + #9 + #9 + sAdoptFee);
    redOutAdoptDet.Lines.Add('Size of pet: ' + #9 + #9 + sSize);

    for iLoopDO := 1 to redOutCharacteristics.lines.count do                // When displaying details in main Rich edit in Adoption tab
    begin                                                                   //(redOutAdoptDet) it creates a tab line down the page for the
      sCharacterOut := #9 + redOutCharacteristics.Lines[iLoopDo-1];         // input in the redOutCharacteristics when it is displayed.

      if iLoopDO = 1
        then
          begin
            redOutAdoptDet.Lines.Add('Pet characteristics:  ' + sCharacterOut);
          end
          else
            begin
              redOutAdoptDet.Lines.Add(#9 + #9 + sCharacterOut);
            end;

      end;

    redOutAdoptDet.Lines.Add('Type of Animal: ' + #9 + #9 + sAnimalType);
    redOutAdoptDet.Lines.Add('Animals Gender: ' + #9 + #9 + redOutGender1.Text);
    redOutAdoptDet.Lines.Add('Time: ' + #9 + #9 + #9 + TimeToStr(tTime));
    redOutAdoptDet.Lines.Add('Date: ' + #9 + #9 + #9 + DateToStr(tDate));

    lstSave.Items.Add('Adoption Details ');
    lstSave.Items.Add('Age: ' + sAge);
    lstSave.Items.Add('Adoption Fee (R): ' + sAdoptFee);
    lstSave.Items.Add('Size of pet(M): ' + sSize);
    lstSave.Items.Add('Pet characteristics:  ' + redOutCharacteristics.Text);
    lstSave.Items.Add('Type of Animal: ' + sAnimalType);
    lstSave.Items.Add('Animals Gender: ' + redOutGender1.Text);
    lstSave.Items.Add('Time: ' + TimeToStr(tTime));
    lstSave.Items.Add('Date: ' + DateToStr(tDate));

end;

procedure TfGermistonSPCAForm.BtnDisplayOutputSurrClick(Sender: TObject);
var
    sAge, sLocation, sSize, sAnimalType, sCharacterOut: String;
    iLoopDo : Integer;

begin
    sAge := ledAge2.Text;
    sLocation := ledLocation.Text;
    sSize := ledSize2.Text;
    sAnimalType := cmbAnimalType2.Text;

    redOutSurrDet.Lines.Add('Surrender Details');
    redOutSurrDet.Lines.Add('Age of animal: ' + #9 + #9 + sAge);
    redOutSurrDet.Lines.Add('Location found: ' + #9 + #9 + sLocation);
    redOutSurrDet.Lines.Add('Size of pet(M): ' + #9 + #9 + sSize);

    for iLoopDO := 1 to redOutCondition.lines.count do
    begin
      sCharacterOut := #9 + redOutCondition.Lines[iLoopDo-1];

      if iLoopDO = 1                                                           // When displaying details in main Rich edit in Surrender tab
        then                                                                   //(redOutSurrDet) it creates a tab line down the page for the
          begin                                                                // input in the redOutCondition when it is displayed.
            redOutSurrDet.Lines.Add('Pet characteristics:  ' + sCharacterOut);
          end
          else
            begin
              redOutSurrDet.Lines.Add(#9 + #9 + sCharacterOut);
            end;

      end;

    redOutSurrDet.Lines.Add('Type of Animal: ' + #9 + #9 + sAnimalType);
    redOutSurrDet.Lines.Add('Animals Gender: ' + #9 + #9 + redOutGender2.Text);
    redOutSurrDet.Lines.Add('Time: ' + #9 + #9 + #9 + TimeToStr(tTime));
    redOutSurrDet.Lines.Add('Date: ' + #9 + #9 + #9 + DateToStr(tDate));

    lstSave.Items.Add('Adoption Details ');
    lstSave.Items.Add('Age: ' + sAge);
    lstSave.Items.Add('Location found: ' + sLocation);
    lstSave.Items.Add('Size of pet (M): ' + sSize);
    lstSave.Items.Add('Pet characteristics:  ' + redOutCondition.Text);
    lstSave.Items.Add('Type of Animal: ' + sAnimalType);
    lstSave.Items.Add('Animals Gender: ' + redOutGender2.Text);
    lstSave.Items.Add('Time: ' + TimeToStr(tTime));
    lstSave.Items.Add('Date: ' + DateToStr(tDate));

end;

procedure TfGermistonSPCAForm.btnGender1Click(Sender: TObject);
var
    iGender : Integer;
    cGender : Char;
begin
    redOutGender1.Clear;
    iGender := StrToInt(Inputbox('Gender','Enter Gender of Animal (77-Male, 70-Female)'
    ,'eg. 70'));

    cGender := CHAR(iGender);

    if iGender = 77                                                    //Using the char valus of the numbers to get M or F
      then                                                             // for female and male, male and female
        begin                                                          // symbols dont work on delphi.
          redOutGender1.Lines.Add(cGender + 'ale');
        end
          else
            if iGender = 70
              then
                begin
                  redOutGender1.Lines.Add(cGender + 'emale');
                end
                else
                  begin
                    ShowMessage('Invalid input');
                  end;

end;

procedure TfGermistonSPCAForm.btnGender2Click(Sender: TObject);
var
    iGender : Integer;
    cGender : Char;
begin
    redOutGender2.Clear;
    iGender := StrToInt(Inputbox('Gender','Enter Gender of Animal (77-Male, 70-Female)'
    ,'eg. 70'));

    cGender := CHAR(iGender);

    if iGender = 77                                                    //Using the char valus of the numbers to get M or F
      then                                                             // for female and male, male and female
        begin                                                          // symbols dont work on delphi.
          redOutGender2.Lines.Add(cGender + 'ale');
        end
          else
            if iGender = 70
              then
                begin
                  redOutGender2.Lines.Add(cGender + 'emale');
                end
                else
                  begin
                    ShowMessage('Invalid input');
                  end;

end;

procedure TfGermistonSPCAForm.btnHelpClick(Sender: TObject);
begin
    HelpFormMain.Show;                              // when the button is clicked it displays the form
end;

procedure TfGermistonSPCAForm.btnPrevPage2Click(Sender: TObject);
var
    bOwnDetTab : Boolean;
    bownDetTab2 : Boolean;
    bSurrTab : Boolean;

begin
    bOwnDetTab := True;
    bOwnDetTab2 := True;
    bSurrTab := False;

    tshOwnersDetails.TabVisible := bOwnDetTab;      // Only shows tab 1's heading at run time
    tshOwnersDetails.Visible := bOwnDetTab2;        // Only tab 1's sheet shows at run time
    tshSurrenderDetails.TabVisible := bSurrTab;

end;

procedure TfGermistonSPCAForm.btnPrevPageClick(Sender: TObject);
var
    bOwnDetTab : Boolean;
    bownDetTab2 : Boolean;
    bAdoptTab : Boolean;

begin
    bOwnDetTab := True;
    bOwnDetTab2 := True;
    bAdoptTab := False;

    tshOwnersDetails.TabVisible := bOwnDetTab;      // Only shows tab 1's heading at run time
    tshOwnersDetails.Visible := bOwnDetTab2;        // Only tab 1's sheet shows at run time
    tshAdoptionDetails.TabVisible := bAdoptTab;

end;

procedure TfGermistonSPCAForm.btnReset1Click(Sender: TObject);
begin
    if (MessageDlg('Are you sure you want to clear this information?',
                              mtWarning, [TMsgDlgBtn.mbYes,mbNo],0) = mrYes)      // To ask if user wants to clear information.
      then
        redOutOwnDet.Clear;
end;


procedure TfGermistonSPCAForm.btnReset2Click(Sender: TObject);
begin
    if (MessageDlg('Are you sure you want to clear this information?',
                              mtWarning, [TMsgDlgBtn.mbYes,mbNo],0) = mrYes)     // To ask if user wants to clear information.
      then
        redOutAdoptDet.Clear;
end;


procedure TfGermistonSPCAForm.btnReset3Click(Sender: TObject);
begin                                                                            // To ask if user wants to clear information
    if (MessageDlg('Are you sure you want to clear this information?',
                              mtWarning, [TMsgDlgBtn.mbYes,mbNo],0) = mrYes)
      then
        redOutSurrDet.Clear;
end;

procedure TfGermistonSPCAForm.btnSaveClose2Click(Sender: TObject);
var
    iLoop : Integer;
    bOwnDetTab : Boolean;
    bOwnDetTab2 : Boolean;
    bSurrTab : Boolean;

begin
    lstSave.Items.SaveToFile(ledName.Text + ' ' + ledSurname.Text + '.txt');       // Saves All information in your name.

    redOutOwnDet.Clear;                              // Resets form for next user to use.
    redOutAdoptDet.Clear;
    redOutSurrDet.Clear;
    redOutCharacteristics.Clear;
    redOutGender1.Clear;
    redOutGender2.Clear;
    redOutList.Clear;
    redOutCondition.Clear;
    lstSave.Clear;
    cmbAnimalType.Text := 'Type of Animal';            // Resets for back to how it was.
    cmbAnimalType2.Text := 'Type of Animal';
    cmbPayment.Text := 'Form of Payment';
    cmbDonations.Text := 'Donated Items';

    for iLoop := 0 to ComponentCount - 1 do              //to clear all labeledEdits
      if Components[iLoop] is TlabeledEdit
        then
          begin
            TLabeledEdit(Components[iLoop]).clear;
          end;

    bOwnDetTab := True;
    bOwnDetTab2 := True;
    bSurrTab := False;

    tshOwnersDetails.TabVisible := bOwnDetTab;
    tshOwnersDetails.Visible := bOwnDetTab2;
    tshSurrenderDetails.TabVisible := bSurrTab;

    ledSize.TextHint := 'Metres (Height)';
    ledSize2.TextHint := 'Metres (Height)';                 //To reset form back to how it was.
    ledDonations.Text := 'R';
    ledAdoptionFee.Text := 'R';
    redOutGender1.Lines.Add('(Gender Displays here)');
    redOutGender2.Lines.Add('(Gender Displays here)');

   if (MessageDlg('You have completed this form',
                              mtInformation, [TMsgDlgBtn.mbOK],0) = mrOK)
    then
      Abort;

end;

procedure TfGermistonSPCAForm.btnSaveCloseClick(Sender: TObject);
var
    iLoop : Integer;
    bOwnDetTab : Boolean;
    bOwnDetTab2 : Boolean;
    bAdoptTab : Boolean;

begin
    lstSave.Items.SaveToFile(ledName.Text + ' ' + ledSurname.Text + '.txt');     // Saves all information in your name.

    redOutOwnDet.Clear;
    redOutAdoptDet.Clear;
    redOutSurrDet.Clear;
    redOutCharacteristics.Clear;
    redOutGender1.Clear;
    redOutGender2.Clear;
    redOutList.Clear;
    redOutCondition.Clear;
    lstSave.Clear;
    cmbAnimalType.Text := 'Type of Animal';
    cmbAnimalType2.Text := 'Type of Animal';
    cmbPayment.Text := 'Form of Payment';
    cmbDonations.Text := 'Donated Items';

    for iLoop := 0 to ComponentCount - 1 do
      if Components[iLoop] is TlabeledEdit              // to clear all labeledEdits
        then
          begin
            TLabeledEdit(Components[iLoop]).clear;
          end;

    bOwnDetTab := True;
    bOwnDetTab2 := True;
    bAdoptTab := False;

    tshOwnersDetails.TabVisible := bOwnDetTab;
    tshOwnersDetails.Visible := bOwnDetTab2;
    tshAdoptionDetails.TabVisible := bAdoptTab;

    ledSize.TextHint := 'Metres (Height)';
    ledSize2.TextHint := 'Metres (Height)';
    ledDonations.Text := 'R';
    ledAdoptionFee.Text := 'R';
    redOutGender1.Lines.Add('(Gender Displays here)');
    redOutGender2.Lines.Add('(Gender Displays here)');

   if (MessageDlg('You have completed this form',
                              mtInformation, [TMsgDlgBtn.mbOK],0) = mrOK)
    then
      Abort;

end;

procedure TfGermistonSPCAForm.btnSurrenderClick(Sender: TObject);
var
    bOwnDetTab : Boolean;
    bAdoptTab : Boolean;
    bAdoptTab2 : Boolean;

begin
    bOwnDetTab := False;
    bAdoptTab := True;
    bAdoptTab2 := True;

    tshSurrenderDetails.Visible := bAdoptTab2;     // Only shows tab 3's heading at run time
    tshSurrenderDetails.TabVisible := bAdoptTab;   // Only tab 3's sheet shows at run time
    tshOwnersDetails.TabVisible := bOwnDetTab;

end;

procedure TfGermistonSPCAForm.cmbDonationsChange(Sender: TObject);
var
    cDonateAmount : Char;
    iDonateAmount : Integer;
    iDonations : Integer;
    iLoop : Integer;
    iDonateLoop : Integer;
    sDonateFood : String;

begin
    iDonations := cmbDonations.ItemIndex;

    cDonateAmount := InputBox('', 'Enter the amount you would like to donate (1-9)', '')[1];   // Item Donation amount

    iDonateAmount := ORD(cDonateAmount);
    iDonateLoop := StrToInt(cDonateAmount);

    if (iDonateAmount <48) OR (iDonateAmount > 57)                  // Vallidation code so that users cant enter letters and
      then                                                          // only numbers.
        begin
          ShowMessage('Invalid Input');
        end
        else
          begin
             redOutList.Lines.Add(cmbDonations.Text + ' ' + '-' + ' ' + cDonateAmount);
          end;

    case iDonations of                                 // When food in the cbmdonations combobox is selected it asked how much
    3 : begin                                          // food you would like to donate and what type of food e.g cat food.
          for iLoop := 1 to iDonateLoop
            do
              begin
                sDonateFood := InputBox('', 'Enter type of food (e.g.Dog food)', '');
                redOutList.Lines.Add('Type of food: ' +  sDonateFood);
              end;
        end;
    end;
end;

procedure TfGermistonSPCAForm.FormCreate(Sender: TObject);
var
    bOwnDetTab : Boolean;
    bOwnDetTab2 : Boolean;
    bSurrenderTab :Boolean;
    bAdoptTab : Boolean;
    bSaveTab : Boolean;

begin
    fGermistonSPCAForm.Caption := 'SPCA Germiston Form';

    bOwnDetTab := True;
    bOwnDetTab2 := True;
    bAdoptTab := False;
    bSurrenderTab := False;
    bSaveTab := False;

    tshOwnersDetails.TabVisible := bOwnDetTab;      // Only shows tab 1's heading at run time
    tshOwnersDetails.Visible := bOwnDetTab2;        // Only tab 1's sheet shows at run time
    tshAdoptionDetails.TabVisible := bAdoptTab;
    tshSurrenderDetails.TabVisible := bSurrenderTab;
    tshSave.TabVisible := bSaveTab;
end;

end.
