﻿	<Project xmlns="http://schemas.microsoft.com/developer/msbuild/2003">
		<PropertyGroup>
			<ProjectGuid>{680CC30E-F5BB-4832-B93E-9B204ECE4121}</ProjectGuid>
		</PropertyGroup>
		<ItemGroup>
			<Projects Include="ITProject1_P.dproj">
				<Dependencies/>
			</Projects>
			<Projects Include="ITProject_P.dproj">
				<Dependencies/>
			</Projects>
		</ItemGroup>
		<ProjectExtensions>
			<Borland.Personality>Default.Personality.12</Borland.Personality>
			<Borland.ProjectType/>
			<BorlandProject>
				<Default.Personality/>
			</BorlandProject>
		</ProjectExtensions>
		<Target Name="ITProject1_P">
			<MSBuild Projects="ITProject1_P.dproj"/>
		</Target>
		<Target Name="ITProject1_P:Clean">
			<MSBuild Targets="Clean" Projects="ITProject1_P.dproj"/>
		</Target>
		<Target Name="ITProject1_P:Make">
			<MSBuild Targets="Make" Projects="ITProject1_P.dproj"/>
		</Target>
		<Target Name="ITProject_P">
			<MSBuild Projects="ITProject_P.dproj"/>
		</Target>
		<Target Name="ITProject_P:Clean">
			<MSBuild Targets="Clean" Projects="ITProject_P.dproj"/>
		</Target>
		<Target Name="ITProject_P:Make">
			<MSBuild Targets="Make" Projects="ITProject_P.dproj"/>
		</Target>
		<Target Name="Build">
			<CallTarget Targets="ITProject1_P;ITProject_P"/>
		</Target>
		<Target Name="Clean">
			<CallTarget Targets="ITProject1_P:Clean;ITProject_P:Clean"/>
		</Target>
		<Target Name="Make">
			<CallTarget Targets="ITProject1_P:Make;ITProject_P:Make"/>
		</Target>
		<Import Project="$(BDS)\Bin\CodeGear.Group.Targets" Condition="Exists('$(BDS)\Bin\CodeGear.Group.Targets')"/>
	</Project>
