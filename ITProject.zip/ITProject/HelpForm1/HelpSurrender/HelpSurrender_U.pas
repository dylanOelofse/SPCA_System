unit HelpSurrender_U;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls;

type
  THelpSurrender = class(TForm)
    pnlHelpSurr: TPanel;
    redOutHelpSurr: TRichEdit;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  HelpSurrender: THelpSurrender;

implementation

{$R *.dfm}

end.
