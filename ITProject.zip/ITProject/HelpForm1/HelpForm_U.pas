unit HelpForm_U;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ExtCtrls, HelpOwners_u, HelpAdoption_u, HelpSurrender_u;

type
  THelpFormMain = class(TForm)
    pnlHelp1: TPanel;
    btnHelpOwners: TButton;
    btnHelpAdopt: TButton;
    btnHelpSurr: TButton;
    procedure btnHelpOwnersClick(Sender: TObject);
    procedure btnHelpAdoptClick(Sender: TObject);
    procedure btnHelpSurrClick(Sender: TObject);
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  HelpFormMain: THelpFormMain;

implementation

{$R *.dfm}

procedure THelpFormMain.btnHelpOwnersClick(Sender: TObject);
begin
    HelpOwners.Show;
end;

procedure THelpFormMain.btnHelpSurrClick(Sender: TObject);
begin
    HelpSurrender.Show;
end;

procedure THelpFormMain.btnHelpAdoptClick(Sender: TObject);
begin
    HelpAdoption.Show;
end;

end.
