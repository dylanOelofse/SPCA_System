object HelpOwners: THelpOwners
  Left = 0
  Top = 0
  Caption = 'Help: Owners Details'
  ClientHeight = 152
  ClientWidth = 289
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object pnlHelpOwn: TPanel
    Left = -8
    Top = -8
    Width = 329
    Height = 225
    Color = clActiveCaption
    ParentBackground = False
    TabOrder = 0
    object redOutHelpOwn: TRichEdit
      Left = 16
      Top = 16
      Width = 273
      Height = 137
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = []
      Lines.Strings = (
        'You are required to enter your '
        'personal details to continue with '
        'the purchase or surrendering of '
        'your/a lost pet. '
        'If you are still struggling to '
        'understand, please ask the satff for '
        'assistance.')
      ParentFont = False
      ReadOnly = True
      ScrollBars = ssVertical
      TabOrder = 0
    end
  end
end
