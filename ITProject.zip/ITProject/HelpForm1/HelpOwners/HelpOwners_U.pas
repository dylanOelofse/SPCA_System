unit HelpOwners_U;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls;

type
  THelpOwners = class(TForm)
    pnlHelpOwn: TPanel;
    redOutHelpOwn: TRichEdit;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  HelpOwners: THelpOwners;

implementation

{$R *.dfm}

end.
