object HelpAdoption: THelpAdoption
  Left = 0
  Top = 0
  Caption = 'Help: Adoption Details'
  ClientHeight = 153
  ClientWidth = 289
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object pnlHelpAdopt: TPanel
    Left = -8
    Top = -24
    Width = 329
    Height = 225
    Color = clActiveCaption
    ParentBackground = False
    TabOrder = 0
    object redOutHelpAdopt: TRichEdit
      Left = 16
      Top = 32
      Width = 273
      Height = 137
      Font.Charset = ANSI_CHARSET
      Font.Color = clWindowText
      Font.Height = -16
      Font.Name = 'Tahoma'
      Font.Style = []
      Lines.Strings = (
        'You are required to enter the  '
        'details/traits of the pet you would '
        'like to purchase. '
        'If you are still struggling to '
        'understand, please ask the satff for '
        'assistance.')
      ParentFont = False
      ReadOnly = True
      ScrollBars = ssVertical
      TabOrder = 0
    end
  end
end
