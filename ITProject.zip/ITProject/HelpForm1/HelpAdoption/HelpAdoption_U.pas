unit HelpAdoption_U;

interface

uses
  Windows, Messages, SysUtils, Variants, Classes, Graphics, Controls, Forms,
  Dialogs, StdCtrls, ComCtrls, ExtCtrls;

type
  THelpAdoption = class(TForm)
    pnlHelpAdopt: TPanel;
    redOutHelpAdopt: TRichEdit;
  private
    { Private declarations }
  public
    { Public declarations }
  end;

var
  HelpAdoption: THelpAdoption;

implementation

{$R *.dfm}

end.
