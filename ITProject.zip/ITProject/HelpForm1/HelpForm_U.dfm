object HelpFormMain: THelpFormMain
  Left = 0
  Top = 0
  Caption = 'HelpFormMain'
  ClientHeight = 134
  ClientWidth = 193
  Color = clBtnFace
  Font.Charset = DEFAULT_CHARSET
  Font.Color = clWindowText
  Font.Height = -11
  Font.Name = 'Tahoma'
  Font.Style = []
  OldCreateOrder = False
  PixelsPerInch = 96
  TextHeight = 13
  object pnlHelp1: TPanel
    Left = -8
    Top = -8
    Width = 207
    Height = 169
    Color = clActiveCaption
    ParentBackground = False
    TabOrder = 0
    object btnHelpOwners: TButton
      Left = 16
      Top = 16
      Width = 177
      Height = 35
      Caption = 'Owners Details'
      TabOrder = 0
      OnClick = btnHelpOwnersClick
    end
    object btnHelpAdopt: TButton
      Left = 16
      Top = 57
      Width = 177
      Height = 35
      Caption = 'Adoption Details'
      TabOrder = 1
      OnClick = btnHelpAdoptClick
    end
    object btnHelpSurr: TButton
      Left = 16
      Top = 99
      Width = 177
      Height = 35
      Caption = 'Surrender Details'
      TabOrder = 2
      OnClick = btnHelpSurrClick
    end
  end
end
